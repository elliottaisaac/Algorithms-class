﻿using System;
using System.Collections.Generic;
using System.IO;


namespace SortingAlgorithms
{
    /// <summary>
    /// uncomment to run each Algorithm
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // SortingAlgorithms.insertionDoubleSort();

            // SortingAlgorithms.insertionGuidSort();

            // SortingAlgorithms.bubbleDoubleSort();

             SortingAlgorithms.bubbleGuidSort();
        }
    }
}