﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SortingAlgorithms
{
    public static class SortingAlgorithms
    {

        public static List<int> listIndex = new List<int>();

        public static List<Guid> listGuid = new List<Guid>();

        public static List<double> listDouble = new List<double>();

        public static List<Guid> MyGuids;

        public static void GenerateGuids()
        {
            string GuidLine = "";
            Random random = new Random();
            int idNum = random.Next(1000000);

            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter("Guids.csv"))
            {
                for (int i = 0; i < 1000000; i++)
                {
                    GuidLine = "";
                    GuidLine += i.ToString() + ",";
                    Guid NewGuid = Guid.NewGuid();
                    GuidLine += NewGuid;
                    double RandDouble = random.NextDouble() * 10;
                    GuidLine += "," + RandDouble.ToString();
                    file.WriteLine(GuidLine);
                }
            }

            using (var reader = new StreamReader("Guids.csv"))
            {

                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    string[] values = line.Split(",", 3,
                     StringSplitOptions.RemoveEmptyEntries);


                    listIndex.Add(Convert.ToInt32(values[0]));
                    listGuid.Add(new Guid(values[1]));
                    listDouble.Add(Convert.ToDouble(values[2]));
                }
            }


        }


        /// <summary>
        /// sources used:
        /// https://stackoverflow.com/questions/5282999/reading-csv-file-and-storing-values-into-an-array
        /// https://www.geeksforgeeks.org/insertion-sort/
        /// https://www.geeksforgeeks.org/bubble-sort/
        /// I shortened to 10000 for speed's sake, but can sort all 1000000 with enough patience
        /// </summary>



        public static List<double> insertionDoubleSort()
        {
            GenerateGuids();

            for (int i = 1; i < 10000; ++i)
            {
                double key = listDouble[i];
                int j = i - 1;

                while (j >= 0 && listDouble[j] > key)
                {
                    listDouble[j + 1] = listDouble[j];
                    j = j - 1;
                }
                listDouble[j + 1] = key;
            }

            for(int h = 1; h < 10000; h++) {Console.WriteLine(listDouble[h] + "\n");}

            return listDouble;
        }


        public static int makeSenseOfGuid(Guid someGuid)
        {
            string GuidString = someGuid.ToString();

            GuidString = GuidString.Substring(0, 7);

            int GuidInt = Convert.ToInt32(GuidString, 16);

            return GuidInt;
        }

        public static List<Guid> insertionGuidSort()
        {
            GenerateGuids();

            for (int k = 1; k < 10000; k++)
            {

                int m = k - 1;

                while (m >= 0 && makeSenseOfGuid(listGuid[k - 1]) > makeSenseOfGuid(listGuid[k]))
                {
                    listDouble[m + 1] = listDouble[m];
                    m = m - 1;
                }
                listGuid[m + 1] = listGuid[k];
            }
            for (int g = 1; g < 10000; g++) { Console.WriteLine(listGuid[g] + "\n"); }

            return listGuid;
        }


        public static List<double> bubbleDoubleSort()
        {
            GenerateGuids();

            for (int n = 0; n < 10000; n++)
            {
                for (int p = 0; p < 10000 - n; p++)
                {
                    if (listDouble[p] > listDouble[p + 1])
                    {
                        double temp = listDouble[p];
                        listDouble[p] = listDouble[p + 1];
                        listDouble[p + 1] = temp;
                    }
                }
            }
            for (int q = 0; q < 10000; ++q) { Console.WriteLine(listDouble[q] + "\n"); }
            return listDouble;
        }



        public static List<Guid> bubbleGuidSort()
        {
            GenerateGuids();

            for (int r = 0; r < 10000; r++)
            {
                for (int s = 0; s < 10000 - r; s++)
                {
                    int GuidInt1 = makeSenseOfGuid(listGuid[s]);

                    int GuidInt2 = makeSenseOfGuid(listGuid[s + 1]);

                    if (GuidInt1 > GuidInt2)
                    {
                        Guid temp2 = listGuid[s];
                        listGuid[s] = listGuid[s + 1];
                        listGuid[s + 1] = temp2;
                    }
                }
            }
            for (int t = 0; t < 10000; t++) { Console.WriteLine(listGuid[t] + "\n"); }
            return listGuid;
        }



    }
}

