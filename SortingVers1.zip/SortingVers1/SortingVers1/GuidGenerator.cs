﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SortingAlgorithms
{
    public class GuidGenerator
    {
        public List<Guid> MyGuids;

        public GuidGenerator()
        {
            MyGuids = new List<Guid>();

        }

        public void GenerateGuids()
        {
            string GuidLine = "";
            Random random = new Random();
            int idNum = random.Next(1000000);

            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter("Guids.csv"))
            {
                for (int i = 0; i < 1000000; i++)
                {
                    GuidLine = "";
                    GuidLine += i.ToString() + ", ";
                    Guid NewGuid = Guid.NewGuid();
                    GuidLine += NewGuid;
                    double RandDouble = random.NextDouble() * 10;
                    GuidLine += ", " + RandDouble.ToString();
                    GuidLine += "\n\r";
                    file.WriteLine(GuidLine);
                }
            }

        }
    }
}
