﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SortingAlgorithms
{
    public static class SortingAlgorithms
    {

        public static List<int> listIndex = new List<int>();

        public static List<Guid> listGuid = new List<Guid>();

        public static List<double> listDouble = new List<double>();

        /// <summary>
        /// sources used: https://stackoverflow.com/questions/5282999/reading-csv-file-and-storing-values-into-an-array
        /// </summary>
        public static void readCSVintoLists()
             {
                using (var reader = new StreamReader("Guids.csv"))
                    {
     
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');

                        listIndex.Add(Convert.ToInt32(values[0]));
                        listGuid.Add(new Guid(values[1]));
                        listDouble.Add(Convert.ToDouble(values[2]));
                    }
                }
             }


        public static List<double> insertionDoubleSort()
        {
            readCSVintoLists();

            for (int i = 1; i < 1000000; ++i)
            {
                double key = listDouble[i];
                int j = i - 1;

                while (j >= 0 && listDouble[j] > key)
                {
                    listDouble[j + 1] = listDouble[j];
                    j = j - 1;
                }
                listDouble[j + 1] = key;
            }

            return listDouble;
        }

        /// <summary>
        /// sources used for insertion sorts: https://www.geeksforgeeks.org/insertion-sort/
        /// </summary>

        public static int makeSenseOfGuid(Guid someGuid)
        {
            string GuidString = someGuid.ToString();

            int GuidInt = Convert.ToInt32(GuidString.Substring(0, 7));

            return GuidInt;
        }

        public static List<Guid> insertionGuidSort()
        {
            readCSVintoLists();

            for (int k = 1; k < 1000000; ++k)
            {

                int idx = makeSenseOfGuid(listGuid[k]);

                int m = k - 1;

                int idx2 = makeSenseOfGuid(listGuid[m]);

                while (m >= 0 && idx2 > idx)
                {
                    listDouble[m + 1] = idx2;
                    m = m - 1;
                }
                listGuid[m + 1] = listGuid[k];
            }

            return listGuid;
        }


        public static List<double> bubbleDoubleSort()
        {
            readCSVintoLists();
      
            for (int l = 0; l < 999999; l++)
                for (int p = 0; p < 999999 - l; p++)
                    if (listDouble[p] > listDouble[p + 1])
                    {
                      
                        int temp = Convert.ToInt32(listDouble[p]);
                        listDouble[p] = listDouble[p + 1];
                        listDouble[p + 1] = temp;
                    }

            return listDouble;
        }




        }
 }

