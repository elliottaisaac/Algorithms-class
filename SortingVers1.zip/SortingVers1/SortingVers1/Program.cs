﻿using System;
using System.Collections.Generic;
using System.IO;


namespace SortingAlgorithms
{
    /// <summary>
    /// I'm getting this weird build error on my VS for mac, so I'm not sure if these work, but I think they should in theory...
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            GuidGenerator GDG = new GuidGenerator();

            SortingAlgorithms.insertionDoubleSort();

        }
    }
}